import JSONBaseVisitor
import JSONParser

class JSONDataVisitor : JSONBaseVisitor<Any>() {

    // file: value EOF
    override fun visitFile(ctx: JSONParser.FileContext): Any {
        return visit(ctx.value())
    }

    // STRING
    override fun visitStringVal(ctx: JSONParser.StringValContext): Any {
        return ctx.STRING().text.removeSurrounding("\"")
    }

    // NUMBER
    override fun visitNumberVal(ctx: JSONParser.NumberValContext): Any {
        val text = ctx.NUMBER().text
        return if (text.contains(".")) text.toDouble() else text.toInt()
    }

    // BOOLEAN
    override fun visitBoolVal(ctx: JSONParser.BoolValContext): Any {
        return ctx.BOOLEAN().text.toBoolean()
    }

    // array: '[' (value (',' value)*)? ']'
    override fun visitArrayVal(ctx: JSONParser.ArrayValContext): Any {
        return ctx.array().value().map { visit(it) }
    }

    // obj: '{' (par (',' par)*)? '}'
    override fun visitObjVal(ctx: JSONParser.ObjValContext): Any {
        return ctx.obj().par().associate { par ->
            val key = par.STRING().text.removeSurrounding("\"")
            val value = visit(par.value())
            key to value
        }
    }
}