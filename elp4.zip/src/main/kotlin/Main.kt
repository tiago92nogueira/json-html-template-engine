
import TemplateAST.Interpreter
import TemplateAST.Script
import org.antlr.v4.runtime.CharStreams
import org.antlr.v4.runtime.CommonTokenStream
import java.io.File

fun main(args: Array<String>) {
    try {
        if (args.size < 3) {
            println("Erro: Faltam argumentos!")
            println("Uso: ./gradlew run --args=\"template.html input.json output.html\"")
            return
        }

        val templateFile = File(args[0])
        val jsonFile = File(args[1])
        val outputFile = File(args[2])

        if (!templateFile.exists()) throw Exception("Ficheiro template não encontrado: ${args[0]}")
        if (!jsonFile.exists()) throw Exception("Ficheiro JSON não encontrado: ${args[1]}")

        val templateContent = templateFile.readText()


        val jsonContent = jsonFile.readText()
        val jsonLexer = JSONLexer(CharStreams.fromString(jsonContent))
        val jsonTokens = CommonTokenStream(jsonLexer)
        val jsonParser = JSONParser(jsonTokens)
        val jsonTree = jsonParser.file()
        val jsonRaw = JSONDataVisitor().visit(jsonTree)
        if (!validate(jsonRaw)) {
            println("Erro: JSON inválido — chaves duplicadas detetadas!")
            return
        }

        val jsonData = jsonRaw as Map<String, Any>
        val interpreter = Interpreter(jsonData)


        // Regex para encontrar blocos {{ ... }}
        val regex = Regex("\\{\\{(.*?)\\}\\}", RegexOption.DOT_MATCHES_ALL)

        val finalResult = regex.replace(templateContent) { matchResult ->
            val scriptCode = "{{" + matchResult.groupValues[1] + "}}"

            try {
                // 1. ANTLR Lexer e Parser
                val lexer = TemplateLexer(CharStreams.fromString(scriptCode))
                val tokens = CommonTokenStream(lexer)
                val parser = TemplateParser(tokens)

                // 2. Criar a Parse Tree
                val tree = parser.script()

                // 3. Converter para AST usando o Visitor
                val ast = BuildAST().visit(tree) as Script

                // 4. Executar e retornar o resultado para a substituição
                interpreter.execute(ast.sequence)
            } catch (e: Exception) {
                " [[ Erro no Script: ${e.message} ]] "
            }
        }

        outputFile.writeText(finalResult)
        println("Sucesso! O ficheiro de output foi gerado em: ${args[2]}")

    } catch (e: Exception) {
        println("\n--- ERRO DE EXECUÇÃO ---")
        e.printStackTrace()
    }
}