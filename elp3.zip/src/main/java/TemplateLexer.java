// Generated from /Users/pedrobrito/Downloads/ELP_P/src/main/kotlin/Template.g4 by ANTLR 4.13.2
import org.antlr.v4.runtime.Lexer;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.TokenStream;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.misc.*;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue", "this-escape"})
public class TemplateLexer extends Lexer {
	static { RuntimeMetaData.checkVersion("4.13.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		IF=1, ENDIF=2, ELSE=3, THEN=4, PRINT=5, END=6, BOOLEAN=7, STRING=8, INT=9, 
		ID=10, OPEN=11, CLOSE=12, OPERATORMUL=13, OPERATORREL=14, ADD=15, MINUS=16, 
		EQUAL=17, TERM=18, OPENBLOCK=19, CLOSEBLOCK=20, COMMENT=21, SPACE=22;
	public static String[] channelNames = {
		"DEFAULT_TOKEN_CHANNEL", "HIDDEN"
	};

	public static String[] modeNames = {
		"DEFAULT_MODE"
	};

	private static String[] makeRuleNames() {
		return new String[] {
			"IF", "ENDIF", "ELSE", "THEN", "PRINT", "END", "BOOLEAN", "STRING", "INT", 
			"ID", "OPEN", "CLOSE", "OPERATORMUL", "OPERATORREL", "ADD", "MINUS", 
			"EQUAL", "TERM", "OPENBLOCK", "CLOSEBLOCK", "COMMENT", "SPACE"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'if'", "'endif'", "'else'", "'then'", "'print'", "'end'", null, 
			null, null, null, "'('", "')'", null, null, "'+'", "'-'", "'='", null, 
			"'{{'", "'}}'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "IF", "ENDIF", "ELSE", "THEN", "PRINT", "END", "BOOLEAN", "STRING", 
			"INT", "ID", "OPEN", "CLOSE", "OPERATORMUL", "OPERATORREL", "ADD", "MINUS", 
			"EQUAL", "TERM", "OPENBLOCK", "CLOSEBLOCK", "COMMENT", "SPACE"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}


	public TemplateLexer(CharStream input) {
		super(input);
		_interp = new LexerATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@Override
	public String getGrammarFileName() { return "Template.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public String[] getChannelNames() { return channelNames; }

	@Override
	public String[] getModeNames() { return modeNames; }

	@Override
	public ATN getATN() { return _ATN; }

	public static final String _serializedATN =
		"\u0004\u0000\u0016\u009e\u0006\uffff\uffff\u0002\u0000\u0007\u0000\u0002"+
		"\u0001\u0007\u0001\u0002\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002"+
		"\u0004\u0007\u0004\u0002\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002"+
		"\u0007\u0007\u0007\u0002\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002"+
		"\u000b\u0007\u000b\u0002\f\u0007\f\u0002\r\u0007\r\u0002\u000e\u0007\u000e"+
		"\u0002\u000f\u0007\u000f\u0002\u0010\u0007\u0010\u0002\u0011\u0007\u0011"+
		"\u0002\u0012\u0007\u0012\u0002\u0013\u0007\u0013\u0002\u0014\u0007\u0014"+
		"\u0002\u0015\u0007\u0015\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0001"+
		"\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0002"+
		"\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0003\u0001\u0003"+
		"\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0004\u0001\u0004\u0001\u0004"+
		"\u0001\u0004\u0001\u0004\u0001\u0004\u0001\u0005\u0001\u0005\u0001\u0005"+
		"\u0001\u0005\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006"+
		"\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0003\u0006T\b\u0006"+
		"\u0001\u0007\u0001\u0007\u0005\u0007X\b\u0007\n\u0007\f\u0007[\t\u0007"+
		"\u0001\u0007\u0001\u0007\u0001\b\u0003\b`\b\b\u0001\b\u0004\bc\b\b\u000b"+
		"\b\f\bd\u0001\t\u0004\th\b\t\u000b\t\f\ti\u0001\n\u0001\n\u0001\u000b"+
		"\u0001\u000b\u0001\f\u0001\f\u0001\r\u0001\r\u0001\r\u0001\r\u0001\r\u0001"+
		"\r\u0001\r\u0001\r\u0001\r\u0001\r\u0003\r|\b\r\u0001\u000e\u0001\u000e"+
		"\u0001\u000f\u0001\u000f\u0001\u0010\u0001\u0010\u0001\u0011\u0004\u0011"+
		"\u0085\b\u0011\u000b\u0011\f\u0011\u0086\u0001\u0012\u0001\u0012\u0001"+
		"\u0012\u0001\u0013\u0001\u0013\u0001\u0013\u0001\u0014\u0001\u0014\u0005"+
		"\u0014\u0091\b\u0014\n\u0014\f\u0014\u0094\t\u0014\u0001\u0014\u0001\u0014"+
		"\u0001\u0015\u0004\u0015\u0099\b\u0015\u000b\u0015\f\u0015\u009a\u0001"+
		"\u0015\u0001\u0015\u0000\u0000\u0016\u0001\u0001\u0003\u0002\u0005\u0003"+
		"\u0007\u0004\t\u0005\u000b\u0006\r\u0007\u000f\b\u0011\t\u0013\n\u0015"+
		"\u000b\u0017\f\u0019\r\u001b\u000e\u001d\u000f\u001f\u0010!\u0011#\u0012"+
		"%\u0013\'\u0014)\u0015+\u0016\u0001\u0000\u0006\u0003\u0000\n\n\r\r\""+
		"\"\u0001\u000009\u0002\u0000AZaz\u0003\u0000%%**//\u0001\u0000\n\n\u0002"+
		"\u0000\t\t  \u00aa\u0000\u0001\u0001\u0000\u0000\u0000\u0000\u0003\u0001"+
		"\u0000\u0000\u0000\u0000\u0005\u0001\u0000\u0000\u0000\u0000\u0007\u0001"+
		"\u0000\u0000\u0000\u0000\t\u0001\u0000\u0000\u0000\u0000\u000b\u0001\u0000"+
		"\u0000\u0000\u0000\r\u0001\u0000\u0000\u0000\u0000\u000f\u0001\u0000\u0000"+
		"\u0000\u0000\u0011\u0001\u0000\u0000\u0000\u0000\u0013\u0001\u0000\u0000"+
		"\u0000\u0000\u0015\u0001\u0000\u0000\u0000\u0000\u0017\u0001\u0000\u0000"+
		"\u0000\u0000\u0019\u0001\u0000\u0000\u0000\u0000\u001b\u0001\u0000\u0000"+
		"\u0000\u0000\u001d\u0001\u0000\u0000\u0000\u0000\u001f\u0001\u0000\u0000"+
		"\u0000\u0000!\u0001\u0000\u0000\u0000\u0000#\u0001\u0000\u0000\u0000\u0000"+
		"%\u0001\u0000\u0000\u0000\u0000\'\u0001\u0000\u0000\u0000\u0000)\u0001"+
		"\u0000\u0000\u0000\u0000+\u0001\u0000\u0000\u0000\u0001-\u0001\u0000\u0000"+
		"\u0000\u00030\u0001\u0000\u0000\u0000\u00056\u0001\u0000\u0000\u0000\u0007"+
		";\u0001\u0000\u0000\u0000\t@\u0001\u0000\u0000\u0000\u000bF\u0001\u0000"+
		"\u0000\u0000\rS\u0001\u0000\u0000\u0000\u000fU\u0001\u0000\u0000\u0000"+
		"\u0011_\u0001\u0000\u0000\u0000\u0013g\u0001\u0000\u0000\u0000\u0015k"+
		"\u0001\u0000\u0000\u0000\u0017m\u0001\u0000\u0000\u0000\u0019o\u0001\u0000"+
		"\u0000\u0000\u001b{\u0001\u0000\u0000\u0000\u001d}\u0001\u0000\u0000\u0000"+
		"\u001f\u007f\u0001\u0000\u0000\u0000!\u0081\u0001\u0000\u0000\u0000#\u0084"+
		"\u0001\u0000\u0000\u0000%\u0088\u0001\u0000\u0000\u0000\'\u008b\u0001"+
		"\u0000\u0000\u0000)\u008e\u0001\u0000\u0000\u0000+\u0098\u0001\u0000\u0000"+
		"\u0000-.\u0005i\u0000\u0000./\u0005f\u0000\u0000/\u0002\u0001\u0000\u0000"+
		"\u000001\u0005e\u0000\u000012\u0005n\u0000\u000023\u0005d\u0000\u0000"+
		"34\u0005i\u0000\u000045\u0005f\u0000\u00005\u0004\u0001\u0000\u0000\u0000"+
		"67\u0005e\u0000\u000078\u0005l\u0000\u000089\u0005s\u0000\u00009:\u0005"+
		"e\u0000\u0000:\u0006\u0001\u0000\u0000\u0000;<\u0005t\u0000\u0000<=\u0005"+
		"h\u0000\u0000=>\u0005e\u0000\u0000>?\u0005n\u0000\u0000?\b\u0001\u0000"+
		"\u0000\u0000@A\u0005p\u0000\u0000AB\u0005r\u0000\u0000BC\u0005i\u0000"+
		"\u0000CD\u0005n\u0000\u0000DE\u0005t\u0000\u0000E\n\u0001\u0000\u0000"+
		"\u0000FG\u0005e\u0000\u0000GH\u0005n\u0000\u0000HI\u0005d\u0000\u0000"+
		"I\f\u0001\u0000\u0000\u0000JK\u0005t\u0000\u0000KL\u0005r\u0000\u0000"+
		"LM\u0005u\u0000\u0000MT\u0005e\u0000\u0000NO\u0005f\u0000\u0000OP\u0005"+
		"a\u0000\u0000PQ\u0005l\u0000\u0000QR\u0005s\u0000\u0000RT\u0005e\u0000"+
		"\u0000SJ\u0001\u0000\u0000\u0000SN\u0001\u0000\u0000\u0000T\u000e\u0001"+
		"\u0000\u0000\u0000UY\u0005\"\u0000\u0000VX\b\u0000\u0000\u0000WV\u0001"+
		"\u0000\u0000\u0000X[\u0001\u0000\u0000\u0000YW\u0001\u0000\u0000\u0000"+
		"YZ\u0001\u0000\u0000\u0000Z\\\u0001\u0000\u0000\u0000[Y\u0001\u0000\u0000"+
		"\u0000\\]\u0005\"\u0000\u0000]\u0010\u0001\u0000\u0000\u0000^`\u0003\u001f"+
		"\u000f\u0000_^\u0001\u0000\u0000\u0000_`\u0001\u0000\u0000\u0000`b\u0001"+
		"\u0000\u0000\u0000ac\u0007\u0001\u0000\u0000ba\u0001\u0000\u0000\u0000"+
		"cd\u0001\u0000\u0000\u0000db\u0001\u0000\u0000\u0000de\u0001\u0000\u0000"+
		"\u0000e\u0012\u0001\u0000\u0000\u0000fh\u0007\u0002\u0000\u0000gf\u0001"+
		"\u0000\u0000\u0000hi\u0001\u0000\u0000\u0000ig\u0001\u0000\u0000\u0000"+
		"ij\u0001\u0000\u0000\u0000j\u0014\u0001\u0000\u0000\u0000kl\u0005(\u0000"+
		"\u0000l\u0016\u0001\u0000\u0000\u0000mn\u0005)\u0000\u0000n\u0018\u0001"+
		"\u0000\u0000\u0000op\u0007\u0003\u0000\u0000p\u001a\u0001\u0000\u0000"+
		"\u0000q|\u0005<\u0000\u0000rs\u0005<\u0000\u0000s|\u0005=\u0000\u0000"+
		"t|\u0005>\u0000\u0000uv\u0005>\u0000\u0000v|\u0005=\u0000\u0000wx\u0005"+
		"=\u0000\u0000x|\u0005=\u0000\u0000yz\u0005<\u0000\u0000z|\u0005>\u0000"+
		"\u0000{q\u0001\u0000\u0000\u0000{r\u0001\u0000\u0000\u0000{t\u0001\u0000"+
		"\u0000\u0000{u\u0001\u0000\u0000\u0000{w\u0001\u0000\u0000\u0000{y\u0001"+
		"\u0000\u0000\u0000|\u001c\u0001\u0000\u0000\u0000}~\u0005+\u0000\u0000"+
		"~\u001e\u0001\u0000\u0000\u0000\u007f\u0080\u0005-\u0000\u0000\u0080 "+
		"\u0001\u0000\u0000\u0000\u0081\u0082\u0005=\u0000\u0000\u0082\"\u0001"+
		"\u0000\u0000\u0000\u0083\u0085\u0005\n\u0000\u0000\u0084\u0083\u0001\u0000"+
		"\u0000\u0000\u0085\u0086\u0001\u0000\u0000\u0000\u0086\u0084\u0001\u0000"+
		"\u0000\u0000\u0086\u0087\u0001\u0000\u0000\u0000\u0087$\u0001\u0000\u0000"+
		"\u0000\u0088\u0089\u0005{\u0000\u0000\u0089\u008a\u0005{\u0000\u0000\u008a"+
		"&\u0001\u0000\u0000\u0000\u008b\u008c\u0005}\u0000\u0000\u008c\u008d\u0005"+
		"}\u0000\u0000\u008d(\u0001\u0000\u0000\u0000\u008e\u0092\u0005#\u0000"+
		"\u0000\u008f\u0091\b\u0004\u0000\u0000\u0090\u008f\u0001\u0000\u0000\u0000"+
		"\u0091\u0094\u0001\u0000\u0000\u0000\u0092\u0090\u0001\u0000\u0000\u0000"+
		"\u0092\u0093\u0001\u0000\u0000\u0000\u0093\u0095\u0001\u0000\u0000\u0000"+
		"\u0094\u0092\u0001\u0000\u0000\u0000\u0095\u0096\u0006\u0014\u0000\u0000"+
		"\u0096*\u0001\u0000\u0000\u0000\u0097\u0099\u0007\u0005\u0000\u0000\u0098"+
		"\u0097\u0001\u0000\u0000\u0000\u0099\u009a\u0001\u0000\u0000\u0000\u009a"+
		"\u0098\u0001\u0000\u0000\u0000\u009a\u009b\u0001\u0000\u0000\u0000\u009b"+
		"\u009c\u0001\u0000\u0000\u0000\u009c\u009d\u0006\u0015\u0000\u0000\u009d"+
		",\u0001\u0000\u0000\u0000\n\u0000SY_di{\u0086\u0092\u009a\u0001\u0006"+
		"\u0000\u0000";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}