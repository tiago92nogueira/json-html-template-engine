grammar Template;

script: OPENBLOCK TERM? sequence+=instruction* CLOSEBLOCK EOF;

instruction: (assign | print | if | COMMENT) TERM*;

assign: ID EQUAL expression;

print: PRINT expression;

if: IF OPEN guard=expression CLOSE THEN TERM+ sequence+=instruction* TERM*
    (ELSE TERM+ alternative+=instruction*)? ENDIF;

expression:
    OPEN inner=expression CLOSE
    | left=expression operator=OPERATORMUL right=expression
    | left=expression operator=(ADD|MINUS) right=expression
    | left=expression operator=OPERATORREL right=expression
    | id=ID
    | value=INT
    | b=BOOLEAN
    | s=STRING;

// --- Keywords PRIMEIRO, antes do ID ---
IF:     'if';
ENDIF:  'endif';
ELSE:   'else';
THEN:   'then';
PRINT:  'print';
END:    'end';
BOOLEAN: 'true' | 'false';

// --- Depois os tokens genéricos ---
STRING: '"' (~["\r\n])* '"';
INT:    MINUS? [0-9]+;
ID:     [a-zA-Z]+;

OPEN:  '(';
CLOSE: ')';

OPERATORMUL: '*' | '/' | '%';
OPERATORREL: '<' | '<=' | '>' | '>=' | '==' | '<>';

ADD:   '+';
MINUS: '-';
EQUAL: '=';

TERM:       '\n'+;
OPENBLOCK:  '{{';
CLOSEBLOCK: '}}';
COMMENT:    '#' ~[\n]* -> skip;
SPACE:      [ \t]+ -> skip;