package TemplateAST

class Interpreter(jsonData: Map<String, Any>) {
    // O scope armazena as variáveis do JSON e as criadas por 'Assign'
    private val scope = jsonData.toMutableMap()

    fun execute(instructions: List<Instruction>): String {
        val output = StringBuilder()
        for (inst in instructions) {
            when (inst) {
                is Assign -> scope[inst.id] = evaluate(inst.expression)
                is Print -> output.append(evaluate(inst.expression))
                is IfElse -> {
                    if (isTrue(evaluate(inst.guard))) {
                        output.append(execute(inst.thenSequence))
                    } else {
                        inst.elseSequence?.let { output.append(execute(it)) }
                    }
                }
            }
        }
        return output.toString()
    }

    private fun evaluate(expr: Expression): Any {
        return when (expr) {
            is IntLiteral -> expr.value
            is StringLiteral ->expr.value
            is BooleanLiteral -> expr.value
            is Variable -> scope[expr.id] ?: throw Exception("Variável '${expr.id}' não definida.")
            is ParenthesizedExpression -> evaluate(expr.inner)
            is BinaryExpression -> {
                val left = evaluate(expr.left)
                val right = evaluate(expr.right)
                computeBinary(left, expr.operator, right)
            }


        }
    }

    private fun isTrue(value: Any): Boolean = when (value) {
        is Boolean -> value
        is Int -> value != 0
        is String -> value.isNotEmpty()
        else -> false
    }

    private fun computeBinary(left: Any, op: String, right: Any): Any {
        val l = left as? Int ?: 0
        val r = right as? Int ?: 0

        return when (op) {
            "+" -> l + r
            "-" -> l - r
            "*" -> l * r
            "/" -> if (r != 0) l / r else 0
            "==" -> left == right
            "!=" -> left != right
            ">" -> l > r
            "<" -> l < r
            ">=" -> l >= r
            "<=" -> l <= r
            else -> throw Exception("Operador '$op' não suportado.")
        }
    }
}