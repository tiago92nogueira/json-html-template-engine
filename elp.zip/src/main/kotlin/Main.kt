import TemplateAST.Interpreter
import java.io.File

fun main(args: Array<String>) {
    try {
        if (args.size < 3) {
            println("Erro: Faltam argumentos!")
            println("Uso: ./gradlew run --args=\"template.html input.json output.html\"")
            return
        }

        val templateFile = File(args[0])
        val jsonFile = File(args[1])

        // Verificação de segurança
        if (!templateFile.exists()) throw Exception("Ficheiro template não encontrado: ${args[0]}")
        if (!jsonFile.exists()) throw Exception("Ficheiro JSON não encontrado: ${args[1]}")

        val templateContent = templateFile.readText()

        // --- TESTE INICIAL: Mapa manual para ver se o resto funciona ---
        val jsonData = mapOf("user" to "Engenheiro", "points" to 120)
        val interpreter = Interpreter(jsonData)

        val regex = Regex("\\{\\{(.*?)\\}\\}", RegexOption.DOT_MATCHES_ALL)

        val finalResult = regex.replace(templateContent) { matchResult ->
            val scriptCode = matchResult.groupValues[1].trim()
            println("A processar bloco: $scriptCode") // Log para debug

            // Se ainda não tens o Visitor do ANTLR pronto,
            // comenta as linhas do parser e retorna um placeholder
            " [SCRIPT_RESULT] "
        }

        File(args[2]).writeText(finalResult)
        println("Sucesso! Output gerado em: ${args[2]}")

    } catch (e: Exception) {
        println("\n--- ERRO DE EXECUÇÃO ---")
        e.printStackTrace() // ISTO vai dizer a linha exata do erro
    }
}