
import org.antlr.v4.runtime.tree.TerminalNode
import java.lang.reflect.UndeclaredThrowableException

// Função principal: transforma parse tree → AST
fun buildAST(ctx: JSONParser.ValueContext): JSONValue {
    //fazer um quando
    return when (ctx){
        is JSONParser.StringValContext-> JString(ctx.STRING().text.removeSurrounding("\""))
        is JSONParser.BoolValContext-> JBoolean(ctx.BOOLEAN().text.toBoolean())
        is JSONParser.NumberValContext-> JNumber(ctx.NUMBER().text.toDouble())
        is JSONParser.ArrayValContext->buildArray(ctx.array())
        is JSONParser.ObjValContext->buildObject(ctx.obj())
        else-> throw RuntimeException("n da");
    }
}

fun buildArray(ctx: JSONParser.ArrayContext):JArray{
    val lista=mutableListOf<JSONValue>()
    for(v in ctx.value()){
        lista.add(buildAST(v))
    }
    return JArray(lista)
}

fun buildObject(ctx:JSONParser.ObjContext): JObject {
    val lista=mutableListOf<JPar>()
    for(v in ctx.par()){
        val key=v.STRING().text.removeSurrounding("\"")
        val value=buildAST(v.value());
        lista.add(JPar(key,value))
    }
    return JObject(lista)

}