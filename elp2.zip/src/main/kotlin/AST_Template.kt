package TemplateAST

// --- Estrutura Base ---

data class SourceRange(val start: Int, val stop: Int, val line: Int)

interface ASTNode {
    val range: SourceRange?
}

// O Script agora reflete a tua regra: OPENBLOCK sequence CLOSEBLOCK
data class Script(
    val sequence: List<Instruction>,
    override val range: SourceRange? = null
) : ASTNode

// --- Instruções ---

sealed interface Instruction : ASTNode

// assign: ID EQUAL expression; (EQUAL é '=' na tua gramática)
data class Assign(
    val id: String,
    val expression: Expression,
    override val range: SourceRange? = null
) : Instruction

// print: 'print' expression;
data class Print(
    val expression: Expression,
    override val range: SourceRange? = null
) : Instruction

// if: IF OPEN guard CLOSE THEN sequence (ELSE THEN alternative)? ENDIF
data class IfElse(
    val guard: Expression,
    val thenSequence: List<Instruction>,
    val elseSequence: List<Instruction>? = null, // null se não houver ELSE
    override val range: SourceRange? = null
) : Instruction

// --- Expressões ---

sealed interface Expression : ASTNode

data class IntLiteral(val value: Int, override val range: SourceRange? = null) : Expression

data class BooleanLiteral(val value: Boolean, override val range: SourceRange? = null) : Expression

data class Variable(val id: String, override val range: SourceRange? = null) : Expression

// Representa left op right
data class BinaryExpression(
    val left: Expression,
    val operator: String, // ex: "+", "-", "==", "<"
    val right: Expression,
    override val range: SourceRange? = null
) : Expression

// Para a regra: OPEN inner=expression CLOSE
// Muitas vezes na AST apenas retornamos o 'inner',
// mas se quiseres manter o registo dos parênteses:
data class ParenthesizedExpression(
    val inner: Expression,
    override val range: SourceRange? = null
) : Expression

// --- Utilitários de Travessia (Visitor Simplificado) ---

fun List<Instruction>.accept(visitor: (Instruction) -> Unit) {
    forEach { inst ->
        visitor(inst)
        if (inst is IfElse) {
            inst.thenSequence.accept(visitor)
            inst.elseSequence?.accept(visitor)
        }
    }
}