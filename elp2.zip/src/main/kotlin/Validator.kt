fun validate(JSON:JSONValue):Boolean{
    val lista=mutableListOf<String>()
    if(JSON is JObject){
        for(v in JSON.pares){
            if(!lista.contains(v.key.toString())){
                lista.add(v.key.toString());
            }else{
                return false;
            }
        }
        return true;
    }else if(JSON is JArray){
        for(v in JSON.values){
            if(!validate(v)){
                return false
            }
        }
    }
    return true;
}
