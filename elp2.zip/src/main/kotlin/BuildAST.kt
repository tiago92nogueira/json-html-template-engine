import TemplateAST.ASTNode
import TemplateAST.Assign
import TemplateAST.BinaryExpression
import TemplateAST.Expression
import TemplateAST.IfElse
import TemplateAST.Instruction
import TemplateAST.IntLiteral
import TemplateAST.ParenthesizedExpression
import TemplateAST.Print
import TemplateAST.Script
import TemplateAST.Variable
import TemplateBaseVisitor
import TemplateParser
import org.antlr.v4.runtime.tree.TerminalNode

class BuildAST : TemplateBaseVisitor<ASTNode>() {

    // script: OPENBLOCK TERM? sequence+=instruction* CLOSEBLOCK EOF;
    override fun visitScript(ctx: TemplateParser.ScriptContext): Script {
        val instructions = ctx.sequence.map { visit(it) as Instruction }
        return Script(instructions)
    }

    // instruction: (assign | print | if | COMMENT) TERM+;
    override fun visitInstruction(ctx: TemplateParser.InstructionContext): Instruction {
        return visit(ctx.getChild(0)) as Instruction
    }

    // assign: ID EQUAL expression;
    override fun visitAssign(ctx: TemplateParser.AssignContext): Assign {
        return Assign(
            id = ctx.ID().text,
            expression = visit(ctx.expression()) as Expression
        )
    }

    // print: 'print' expression;
    override fun visitPrint(ctx: TemplateParser.PrintContext): Print {
        return Print(expression = visit(ctx.expression()) as Expression)
    }

    // if: IF OPEN guard=expression CLOSE THEN TERM+ sequence+=instruction* TERM* ...
    override fun visitIf(ctx: TemplateParser.IfContext): IfElse {
        val guard = visit(ctx.guard) as Expression
        val thenSeq = ctx.sequence.map { visit(it) as Instruction }

        // Verifica se existe o bloco ELSE
        val elseSeq = if (ctx.alternative.isNotEmpty()) {
            ctx.alternative.map { visit(it) as Instruction }
        } else null

        return IfElse(guard, thenSeq, elseSeq)
    }

    // expression: Lógica de precedência
    override fun visitExpression(ctx: TemplateParser.ExpressionContext): Expression {
        return when {
            // Parênteses: OPEN inner=expression CLOSE
            ctx.OPEN() != null && ctx.inner != null ->
                ParenthesizedExpression(visit(ctx.inner) as Expression)

            // Operações Binárias (Multiplicação, Soma, Relacional)
            ctx.left != null && ctx.right != null -> {
                val op = ctx.operator?.text ?: ctx.getChild(1).text
                BinaryExpression(
                    left = visit(ctx.left) as Expression,
                    operator = op,
                    right = visit(ctx.right) as Expression
                )
            }

            // ID (Variável)
            ctx.id != null -> Variable(ctx.id.text)

            // INT (Literal)
            ctx.value != null -> IntLiteral(ctx.value.text.toInt())

            else -> throw Exception("Expressão não suportada na linha ${ctx.start.line}")
        }
    }
}