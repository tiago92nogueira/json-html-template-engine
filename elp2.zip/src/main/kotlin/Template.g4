grammar Template;

script:  OPENBLOCK TERM? sequence+=instruction* CLOSEBLOCK EOF;


instruction: (assign | print | if | COMMENT) TERM+;

assign: ID EQUAL expression;

print: 'print' expression;



if: IF OPEN guard=expression CLOSE THEN TERM+ sequence+=instruction* TERM*
(ELSE THEN TERM* alternative+=instruction*)? ENDIF;


expression:
OPEN inner=expression CLOSE
| left=expression operator=OPERATORMUL right=expression
| left=expression operator=(ADD|MINUS) right=expression
| left=expression operator=OPERATORREL right=expression
| id=ID
| value=INT;


IF: 'if';
ENDIF:'endif';
ELSE: 'else';
PRINT: 'print';

ID: [a-zA-Z]+;

INT: MINUS?[0-9]+;
BOOLEAN:'true'|'false';

THEN:'then';
END:'end';

OPEN: '(';
CLOSE: ')';


OPERATORMUL: '*'|'/'|'%';
OPERATORREL: '<'|'<='|'>'|'>='|'=='|'<>';

ADD: '+';
MINUS: '-';

EQUAL: '=';

TERM:'\n'+;
OPENBLOCK: '{{';
CLOSEBLOCK: '}}';
COMMENT: '#'~[\n]* -> skip;
SPACE: [ \t]+ -> skip;