// Generated from /Users/pedrobrito/Downloads/ELP_P/src/main/kotlin/Template.g4 by ANTLR 4.13.2
import org.antlr.v4.runtime.Lexer;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.TokenStream;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.misc.*;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue", "this-escape"})
public class TemplateLexer extends Lexer {
	static { RuntimeMetaData.checkVersion("4.13.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		IF=1, ENDIF=2, ELSE=3, PRINT=4, ID=5, INT=6, BOOLEAN=7, THEN=8, END=9, 
		OPEN=10, CLOSE=11, OPERATORMUL=12, OPERATORREL=13, ADD=14, MINUS=15, EQUAL=16, 
		TERM=17, OPENBLOCK=18, CLOSEBLOCK=19, COMMENT=20, SPACE=21;
	public static String[] channelNames = {
		"DEFAULT_TOKEN_CHANNEL", "HIDDEN"
	};

	public static String[] modeNames = {
		"DEFAULT_MODE"
	};

	private static String[] makeRuleNames() {
		return new String[] {
			"IF", "ENDIF", "ELSE", "PRINT", "ID", "INT", "BOOLEAN", "THEN", "END", 
			"OPEN", "CLOSE", "OPERATORMUL", "OPERATORREL", "ADD", "MINUS", "EQUAL", 
			"TERM", "OPENBLOCK", "CLOSEBLOCK", "COMMENT", "SPACE"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'if'", "'endif'", "'else'", "'print'", null, null, null, "'then'", 
			"'end'", "'('", "')'", null, null, "'+'", "'-'", "'='", null, "'{{'", 
			"'}}'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "IF", "ENDIF", "ELSE", "PRINT", "ID", "INT", "BOOLEAN", "THEN", 
			"END", "OPEN", "CLOSE", "OPERATORMUL", "OPERATORREL", "ADD", "MINUS", 
			"EQUAL", "TERM", "OPENBLOCK", "CLOSEBLOCK", "COMMENT", "SPACE"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}


	public TemplateLexer(CharStream input) {
		super(input);
		_interp = new LexerATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@Override
	public String getGrammarFileName() { return "Template.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public String[] getChannelNames() { return channelNames; }

	@Override
	public String[] getModeNames() { return modeNames; }

	@Override
	public ATN getATN() { return _ATN; }

	public static final String _serializedATN =
		"\u0004\u0000\u0015\u0093\u0006\uffff\uffff\u0002\u0000\u0007\u0000\u0002"+
		"\u0001\u0007\u0001\u0002\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002"+
		"\u0004\u0007\u0004\u0002\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0002"+
		"\u0007\u0007\u0007\u0002\b\u0007\b\u0002\t\u0007\t\u0002\n\u0007\n\u0002"+
		"\u000b\u0007\u000b\u0002\f\u0007\f\u0002\r\u0007\r\u0002\u000e\u0007\u000e"+
		"\u0002\u000f\u0007\u000f\u0002\u0010\u0007\u0010\u0002\u0011\u0007\u0011"+
		"\u0002\u0012\u0007\u0012\u0002\u0013\u0007\u0013\u0002\u0014\u0007\u0014"+
		"\u0001\u0000\u0001\u0000\u0001\u0000\u0001\u0001\u0001\u0001\u0001\u0001"+
		"\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0002\u0001\u0002\u0001\u0002"+
		"\u0001\u0002\u0001\u0002\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003"+
		"\u0001\u0003\u0001\u0003\u0001\u0004\u0004\u0004A\b\u0004\u000b\u0004"+
		"\f\u0004B\u0001\u0005\u0003\u0005F\b\u0005\u0001\u0005\u0004\u0005I\b"+
		"\u0005\u000b\u0005\f\u0005J\u0001\u0006\u0001\u0006\u0001\u0006\u0001"+
		"\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006\u0003"+
		"\u0006V\b\u0006\u0001\u0007\u0001\u0007\u0001\u0007\u0001\u0007\u0001"+
		"\u0007\u0001\b\u0001\b\u0001\b\u0001\b\u0001\t\u0001\t\u0001\n\u0001\n"+
		"\u0001\u000b\u0001\u000b\u0001\f\u0001\f\u0001\f\u0001\f\u0001\f\u0001"+
		"\f\u0001\f\u0001\f\u0001\f\u0001\f\u0003\fq\b\f\u0001\r\u0001\r\u0001"+
		"\u000e\u0001\u000e\u0001\u000f\u0001\u000f\u0001\u0010\u0004\u0010z\b"+
		"\u0010\u000b\u0010\f\u0010{\u0001\u0011\u0001\u0011\u0001\u0011\u0001"+
		"\u0012\u0001\u0012\u0001\u0012\u0001\u0013\u0001\u0013\u0005\u0013\u0086"+
		"\b\u0013\n\u0013\f\u0013\u0089\t\u0013\u0001\u0013\u0001\u0013\u0001\u0014"+
		"\u0004\u0014\u008e\b\u0014\u000b\u0014\f\u0014\u008f\u0001\u0014\u0001"+
		"\u0014\u0000\u0000\u0015\u0001\u0001\u0003\u0002\u0005\u0003\u0007\u0004"+
		"\t\u0005\u000b\u0006\r\u0007\u000f\b\u0011\t\u0013\n\u0015\u000b\u0017"+
		"\f\u0019\r\u001b\u000e\u001d\u000f\u001f\u0010!\u0011#\u0012%\u0013\'"+
		"\u0014)\u0015\u0001\u0000\u0005\u0002\u0000AZaz\u0001\u000009\u0003\u0000"+
		"%%**//\u0001\u0000\n\n\u0002\u0000\t\t  \u009e\u0000\u0001\u0001\u0000"+
		"\u0000\u0000\u0000\u0003\u0001\u0000\u0000\u0000\u0000\u0005\u0001\u0000"+
		"\u0000\u0000\u0000\u0007\u0001\u0000\u0000\u0000\u0000\t\u0001\u0000\u0000"+
		"\u0000\u0000\u000b\u0001\u0000\u0000\u0000\u0000\r\u0001\u0000\u0000\u0000"+
		"\u0000\u000f\u0001\u0000\u0000\u0000\u0000\u0011\u0001\u0000\u0000\u0000"+
		"\u0000\u0013\u0001\u0000\u0000\u0000\u0000\u0015\u0001\u0000\u0000\u0000"+
		"\u0000\u0017\u0001\u0000\u0000\u0000\u0000\u0019\u0001\u0000\u0000\u0000"+
		"\u0000\u001b\u0001\u0000\u0000\u0000\u0000\u001d\u0001\u0000\u0000\u0000"+
		"\u0000\u001f\u0001\u0000\u0000\u0000\u0000!\u0001\u0000\u0000\u0000\u0000"+
		"#\u0001\u0000\u0000\u0000\u0000%\u0001\u0000\u0000\u0000\u0000\'\u0001"+
		"\u0000\u0000\u0000\u0000)\u0001\u0000\u0000\u0000\u0001+\u0001\u0000\u0000"+
		"\u0000\u0003.\u0001\u0000\u0000\u0000\u00054\u0001\u0000\u0000\u0000\u0007"+
		"9\u0001\u0000\u0000\u0000\t@\u0001\u0000\u0000\u0000\u000bE\u0001\u0000"+
		"\u0000\u0000\rU\u0001\u0000\u0000\u0000\u000fW\u0001\u0000\u0000\u0000"+
		"\u0011\\\u0001\u0000\u0000\u0000\u0013`\u0001\u0000\u0000\u0000\u0015"+
		"b\u0001\u0000\u0000\u0000\u0017d\u0001\u0000\u0000\u0000\u0019p\u0001"+
		"\u0000\u0000\u0000\u001br\u0001\u0000\u0000\u0000\u001dt\u0001\u0000\u0000"+
		"\u0000\u001fv\u0001\u0000\u0000\u0000!y\u0001\u0000\u0000\u0000#}\u0001"+
		"\u0000\u0000\u0000%\u0080\u0001\u0000\u0000\u0000\'\u0083\u0001\u0000"+
		"\u0000\u0000)\u008d\u0001\u0000\u0000\u0000+,\u0005i\u0000\u0000,-\u0005"+
		"f\u0000\u0000-\u0002\u0001\u0000\u0000\u0000./\u0005e\u0000\u0000/0\u0005"+
		"n\u0000\u000001\u0005d\u0000\u000012\u0005i\u0000\u000023\u0005f\u0000"+
		"\u00003\u0004\u0001\u0000\u0000\u000045\u0005e\u0000\u000056\u0005l\u0000"+
		"\u000067\u0005s\u0000\u000078\u0005e\u0000\u00008\u0006\u0001\u0000\u0000"+
		"\u00009:\u0005p\u0000\u0000:;\u0005r\u0000\u0000;<\u0005i\u0000\u0000"+
		"<=\u0005n\u0000\u0000=>\u0005t\u0000\u0000>\b\u0001\u0000\u0000\u0000"+
		"?A\u0007\u0000\u0000\u0000@?\u0001\u0000\u0000\u0000AB\u0001\u0000\u0000"+
		"\u0000B@\u0001\u0000\u0000\u0000BC\u0001\u0000\u0000\u0000C\n\u0001\u0000"+
		"\u0000\u0000DF\u0003\u001d\u000e\u0000ED\u0001\u0000\u0000\u0000EF\u0001"+
		"\u0000\u0000\u0000FH\u0001\u0000\u0000\u0000GI\u0007\u0001\u0000\u0000"+
		"HG\u0001\u0000\u0000\u0000IJ\u0001\u0000\u0000\u0000JH\u0001\u0000\u0000"+
		"\u0000JK\u0001\u0000\u0000\u0000K\f\u0001\u0000\u0000\u0000LM\u0005t\u0000"+
		"\u0000MN\u0005r\u0000\u0000NO\u0005u\u0000\u0000OV\u0005e\u0000\u0000"+
		"PQ\u0005f\u0000\u0000QR\u0005a\u0000\u0000RS\u0005l\u0000\u0000ST\u0005"+
		"s\u0000\u0000TV\u0005e\u0000\u0000UL\u0001\u0000\u0000\u0000UP\u0001\u0000"+
		"\u0000\u0000V\u000e\u0001\u0000\u0000\u0000WX\u0005t\u0000\u0000XY\u0005"+
		"h\u0000\u0000YZ\u0005e\u0000\u0000Z[\u0005n\u0000\u0000[\u0010\u0001\u0000"+
		"\u0000\u0000\\]\u0005e\u0000\u0000]^\u0005n\u0000\u0000^_\u0005d\u0000"+
		"\u0000_\u0012\u0001\u0000\u0000\u0000`a\u0005(\u0000\u0000a\u0014\u0001"+
		"\u0000\u0000\u0000bc\u0005)\u0000\u0000c\u0016\u0001\u0000\u0000\u0000"+
		"de\u0007\u0002\u0000\u0000e\u0018\u0001\u0000\u0000\u0000fq\u0005<\u0000"+
		"\u0000gh\u0005<\u0000\u0000hq\u0005=\u0000\u0000iq\u0005>\u0000\u0000"+
		"jk\u0005>\u0000\u0000kq\u0005=\u0000\u0000lm\u0005=\u0000\u0000mq\u0005"+
		"=\u0000\u0000no\u0005<\u0000\u0000oq\u0005>\u0000\u0000pf\u0001\u0000"+
		"\u0000\u0000pg\u0001\u0000\u0000\u0000pi\u0001\u0000\u0000\u0000pj\u0001"+
		"\u0000\u0000\u0000pl\u0001\u0000\u0000\u0000pn\u0001\u0000\u0000\u0000"+
		"q\u001a\u0001\u0000\u0000\u0000rs\u0005+\u0000\u0000s\u001c\u0001\u0000"+
		"\u0000\u0000tu\u0005-\u0000\u0000u\u001e\u0001\u0000\u0000\u0000vw\u0005"+
		"=\u0000\u0000w \u0001\u0000\u0000\u0000xz\u0005\n\u0000\u0000yx\u0001"+
		"\u0000\u0000\u0000z{\u0001\u0000\u0000\u0000{y\u0001\u0000\u0000\u0000"+
		"{|\u0001\u0000\u0000\u0000|\"\u0001\u0000\u0000\u0000}~\u0005{\u0000\u0000"+
		"~\u007f\u0005{\u0000\u0000\u007f$\u0001\u0000\u0000\u0000\u0080\u0081"+
		"\u0005}\u0000\u0000\u0081\u0082\u0005}\u0000\u0000\u0082&\u0001\u0000"+
		"\u0000\u0000\u0083\u0087\u0005#\u0000\u0000\u0084\u0086\b\u0003\u0000"+
		"\u0000\u0085\u0084\u0001\u0000\u0000\u0000\u0086\u0089\u0001\u0000\u0000"+
		"\u0000\u0087\u0085\u0001\u0000\u0000\u0000\u0087\u0088\u0001\u0000\u0000"+
		"\u0000\u0088\u008a\u0001\u0000\u0000\u0000\u0089\u0087\u0001\u0000\u0000"+
		"\u0000\u008a\u008b\u0006\u0013\u0000\u0000\u008b(\u0001\u0000\u0000\u0000"+
		"\u008c\u008e\u0007\u0004\u0000\u0000\u008d\u008c\u0001\u0000\u0000\u0000"+
		"\u008e\u008f\u0001\u0000\u0000\u0000\u008f\u008d\u0001\u0000\u0000\u0000"+
		"\u008f\u0090\u0001\u0000\u0000\u0000\u0090\u0091\u0001\u0000\u0000\u0000"+
		"\u0091\u0092\u0006\u0014\u0000\u0000\u0092*\u0001\u0000\u0000\u0000\t"+
		"\u0000BEJUp{\u0087\u008f\u0001\u0006\u0000\u0000";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}